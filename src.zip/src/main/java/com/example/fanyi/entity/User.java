package com.example.fanyi.entity;

import com.alibaba.fastjson.JSONObject;

import java.util.Map;

public class User {
    private String id;
    private String passWord;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }




    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public JSONObject tojson(){
        JSONObject b= new JSONObject();
        b.put("id", id);
        b.put("password", passWord);
        return b;
    }
}
