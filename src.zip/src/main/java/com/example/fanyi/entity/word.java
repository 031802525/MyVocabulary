package com.example.fanyi.entity;

import com.alibaba.fastjson.JSONObject;

public class word {
    public String content;
    public String phonetic;
    public String explaination;

    public String getContent() {
        return content;
    }

    public void setId(String id) {
        this.content = content;
    }

    public String getExplaination() { return explaination; }

    public void setExplaination(String explaination) { this.explaination = explaination; }

    public String getphonetic() {
        return phonetic;
    }

    public void setPassWord(String passWord) {
        this.phonetic = phonetic;
    }


    public JSONObject tojson(){
        JSONObject b= new JSONObject();
        b.put("content", content);
        b.put("phonetic",phonetic );
        b.put("explaination",explaination );
        return b;
    }
}
