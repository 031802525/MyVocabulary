package com.example.fanyi.entity;

public class SimilarWord {
    private String Scontent;
}
