package com.example.fanyi.internat;
import com.alibaba.fastjson.JSONObject;
import com.example.fanyi.internat.baiduapi.transapi;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class sentence {
    private static final String APP_ID = "20201028000601287";
    private static final String SECURITY_KEY = "BZOVl4fUVzUbpgxmbmwk";

    public JSONObject adc(String danci,String mu){
        transapi api = new transapi(APP_ID, SECURITY_KEY);

        String query = danci;
        String jsonstr=api.getTransResult(query, "auto", mu);
        JSONObject objJson = JSONObject.parseObject(jsonstr);
        String result=objJson.getJSONArray("trans_result").getJSONObject(0).getString("dst");
        System.out.println(objJson);
        return objJson;
    }
    @RequestMapping("/fanyizh")
    public JSONObject hello(@RequestParam(value = "zhongwen", defaultValue = "wu") String zhongwen) {
        return adc(zhongwen,"en");
    }
    @RequestMapping("/fanyien")
    public JSONObject EN(@RequestParam(value = "yingwen", defaultValue = "no english") String yingwen) {
        return adc(yingwen,"zh");
    }
}