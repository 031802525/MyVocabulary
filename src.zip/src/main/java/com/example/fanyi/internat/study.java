package com.example.fanyi.internat;

import com.example.fanyi.entity.word;
import com.alibaba.fastjson.JSONObject;
import com.example.fanyi.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.fanyi.mapper.studymapper;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;

import java.util.List;

@RestController
public class study {
    @Autowired
    studymapper study;
    @Autowired
    UserMapper user;

    @RequestMapping("/study4")
    public JSONObject siji(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:") + 3, name.indexOf("."));
        String num=user.getplan(id);
        List p = new ArrayList();
        int xue=study.record(id,"4");
        int shuliang;
        shuliang = Integer.valueOf(num);
        for (int i = xue; i < xue + shuliang; i++) {
            word a = study.study8(i);
            p.add(a.tojson());
        }
        String h=String.valueOf(shuliang+xue);
        study.changerecourd(id,"4",h);
        JSONObject d = new JSONObject();
        d.put("4",p);
        return d;
    }

    @RequestMapping("/study6")
    public JSONObject liuji(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:") + 3, name.indexOf("."));
        String num=user.getplan(id);
        int xue=study.record(id,"6");
        List p = new ArrayList();
        int shuliang;
        shuliang = Integer.valueOf(num);
        for (int i = xue; i < xue + shuliang; i++) {
            word a = study.study8(i);
            p.add(a.tojson());
        }
        String h=String.valueOf(shuliang+xue);
        study.changerecourd(id,"6",h);
        JSONObject d = new JSONObject();
        d.put("6",p);
        return d;
    }

    @RequestMapping("/study8")
    public JSONObject kaoyan(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:") + 3, name.indexOf("."));
        String num=user.getplan(id);
        List p = new ArrayList();
        int xue=study.record(id,"8");
        System.out.println(xue);
        int shuliang;
        shuliang = Integer.valueOf(num);
        for (int i = xue; i < xue + shuliang; i++) {
            word a = study.study8(i);
            p.add(a.tojson());
        }
        String h=String.valueOf(shuliang+xue);
        study.changerecourd(id,"8",h);
        JSONObject d = new JSONObject();
        d.put("8",p);
        return d;
    }
}
