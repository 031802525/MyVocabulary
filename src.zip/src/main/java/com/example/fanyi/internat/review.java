package com.example.fanyi.internat;

import com.alibaba.fastjson.JSONObject;
import com.example.fanyi.entity.word;
import com.example.fanyi.mapper.studymapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.Random;


import java.util.ArrayList;
import java.util.List;

@RestController
public class review {
    @Autowired
    studymapper study;

    @RequestMapping("/review4")
    public JSONObject siji(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:") + 3, name.indexOf("num="));
        String num = name.substring(name.indexOf("num=") + 4, name.indexOf("."));
        JSONObject c = new JSONObject();
        int xue=study.record(id,"4");
        List p = new ArrayList();
        int shuliang;
        shuliang = Integer.valueOf(num);
        int qujian=xue/shuliang;
        for (int i = 1; i < shuliang + 1; i++) {
            Random rand=new Random();
            int min=1+qujian*(i-1);
            word a = study.study4(rand.nextInt(qujian)+min);
            p.add(a.tojson());
        }
        JSONObject d = new JSONObject();
        d.put("4", p);
        d.put("num",xue);
        return d;
    }

    @RequestMapping("/review6")
    public JSONObject liuji(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:") + 3, name.indexOf("num="));
        String num = name.substring(name.indexOf("num=") + 4, name.indexOf("."));
        JSONObject c = new JSONObject();
        int xue=study.record(id,"6");
        List p = new ArrayList();
        int shuliang;
        shuliang = Integer.valueOf(num);
        int qujian=xue/shuliang;
        for (int i = 1; i < shuliang + 1; i++) {
            Random rand=new Random();
            int min=1+qujian*(i-1);
            word a = study.study6(rand.nextInt(qujian)+min);
            p.add(a.tojson());
        }
        JSONObject d = new JSONObject();
        d.put("6", p);
        d.put("num",xue);
        return d;
    }

    @RequestMapping("/review8")
    public JSONObject kaoyan(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:") + 3, name.indexOf("num="));
        String num = name.substring(name.indexOf("num=") + 4, name.indexOf("."));
        JSONObject c = new JSONObject();
        int xue=study.record(id,"8");
        List p = new ArrayList();
        int shuliang;
        shuliang = Integer.valueOf(num);
        int qujian=xue/shuliang;
        for (int i = 1; i < shuliang + 1; i++) {
            Random rand=new Random();
            int min=1+qujian*(i-1);
            word a = study.study8(rand.nextInt(qujian)+min);
            p.add(a.tojson());
        }
        JSONObject d = new JSONObject();
        d.put("8", p);
        d.put("num",xue);
        return d;
    }
}