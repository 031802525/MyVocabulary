package com.example.fanyi.control;

import com.alibaba.fastjson.JSONObject;
import com.example.fanyi.entity.User;
import com.example.fanyi.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;


@RestController
public class UserControl {

    @Autowired
    UserMapper userMapper;

@RequestMapping("/user")
public JSONObject hello(@RequestParam(value = "name", defaultValue = "id:1mima:.") String name) {
    String id = name.substring(name.indexOf("id:")+3,name.indexOf("mima:"));
    String mima=name.substring(name.indexOf("mima:")+5,name.indexOf("."));
    User shuju=userMapper.Sel(id);
    return  shuju.tojson();
}
    @GetMapping("/createuser")
    public JSONObject cr(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:")+3,name.indexOf("mima:"));
        String mima=name.substring(name.indexOf("mima:")+5,name.indexOf("."));
        userMapper.insertuser(id,mima);
        userMapper.insertuserplan(id,"10");
        userMapper.insertusertype4(id,"4");
        userMapper.insertusertype8(id,"8");
        userMapper.insertusertype6(id,"6");
        userMapper.insertusersign(id);
        JSONObject b=new JSONObject();
        b.put("type","success");
        return b;
    }
    @GetMapping("/deletuser")
    public JSONObject delet(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:")+3,name.indexOf("mima:"));
        String mima=name.substring(name.indexOf("mima:")+5,name.indexOf("."));
        userMapper.deletbyid(id);
        userMapper.deletbyidplan(id);
        userMapper.deletbyidtype(id);
        userMapper.deletbyidsign(id);
        JSONObject b=new JSONObject();
        b.put("type","success");
        return b;
    }
    @GetMapping("/changepassword")
    public JSONObject change(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:")+3,name.indexOf("mima:"));
        String mima=name.substring(name.indexOf("mima:")+5,name.indexOf("."));
        userMapper.change(id,mima);
        JSONObject b=new JSONObject();
        b.put("type","success");
        return b;
    }
    @GetMapping("/changeplan")
    public JSONObject plan(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:")+3,name.indexOf("plan:"));
        String plan=name.substring(name.indexOf("plan:")+5,name.indexOf("."));
        userMapper.changeplan(id,plan);
        JSONObject b=new JSONObject();
        b.put("type","success");
        return b;
    }
    @GetMapping("/getplan")
    public JSONObject getplan(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:")+3,name.indexOf("."));
        String c=userMapper.getplan(id);
        JSONObject b=new JSONObject();
        b.put("plan",c);
        return b;
    }
    @GetMapping("/getsign")
    public JSONObject getsign(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:")+3,name.indexOf("."));
        int c=userMapper.getsign(id);
        JSONObject b=new JSONObject();
        b.put("time",c);
        return b;
    }
    @GetMapping("/changesign")
    public JSONObject changesign(@RequestParam(value = "name", defaultValue = "wu") String name) {
        String id = name.substring(name.indexOf("id:")+3,name.indexOf("."));
        int c=userMapper.getsign(id);
        c++;
        String time=String.valueOf(c);
        userMapper.changesign(id,time);
        JSONObject b=new JSONObject();
        b.put("time",c);
        return b;
    }
}
