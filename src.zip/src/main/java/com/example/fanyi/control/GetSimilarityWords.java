package com.example.fanyi.control;

import com.alibaba.fastjson.JSONObject;
import com.example.fanyi.mapper.studymapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

import static java.util.Map.Entry.comparingByValue;
import static java.util.stream.Collectors.toMap;

@RestController
public class GetSimilarityWords {
    @Autowired
    studymapper stu;

    public  JSONObject getsimilarword(String word) {
        int num= 3;
        List<String>  p = stu.w();
        Map<String,Double>p1=new Hashtable<>();
        Similarity s = new Similarity();
        for(int i =0;i<p.size();i++){
            p1.put(p.get(i), (double) s.levenshtein(word,p.get(i)));
        }
        Map<String, Double> sorted = p1
                .entrySet()
                .stream()
                .sorted(Collections.reverseOrder(comparingByValue()))
                .collect(
                        toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) ->e1,
                                LinkedHashMap::new));
        //System.out.println("降序按值排序后的map: " + sorted);
        JSONObject a  =new JSONObject();
        List<String>t= new ArrayList<>();
        int i =0;
        for (String key : sorted.keySet()) {
            if(i==0)
            {
                i++;
                continue;
            }
            t.add(key);
            if(i++>(num-1))  break;
        }
        a.put(word,t);
        return  a;
    }

    @GetMapping(value = "/s4")
    public  JSONObject get1(@RequestParam(value = "word",defaultValue = "null") String word) {
       return getsimilarword(word);
    }

    @GetMapping(value = "/s6")
    public  JSONObject get2(@RequestParam(value = "word",defaultValue = "null") String word) {
        return getsimilarword(word);
    }

    @GetMapping(value = "/s8")
    public  JSONObject get3(@RequestParam(value = "word",defaultValue = "null") String word) {
        return getsimilarword(word);
    }

}



