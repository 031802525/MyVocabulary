package com.example.fanyi.mapper;

import com.example.fanyi.entity.word;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface studymapper {
    word study4(int id);
    word study8(int id);
    word study6(int id);
    int record(String id,String type);
    void changerecourd(String id,String type,String record);
    List<String> w();         //四级相似的
    List<String> w1();       //六级相似的
    List<String> w2();       //考研词汇相似的
}