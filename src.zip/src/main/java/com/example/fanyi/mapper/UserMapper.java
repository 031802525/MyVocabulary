package com.example.fanyi.mapper;

import com.example.fanyi.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserMapper {
    User Sel(String id);
    void insertuser(String id,String password);
    void deletbyid(String id);
    void insertuserplan(String id,String num);
    void insertusertype4(String id,String type);
    void insertusertype6(String id,String type);
    void insertusertype8(String id,String type);
    void deletbyidplan(String id);
    void deletbyidtype(String id);
    void deletbyidsign(String id);
    void change(String id,String password);
    void changeplan(String id,String plan);
    String getplan(String id);
    void insertusersign(String id);
    int getsign(String id);
    void changesign(String id,String time);
}